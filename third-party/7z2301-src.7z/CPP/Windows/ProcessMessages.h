// Windows/ProcessMessages.h

#ifndef ZIP7_INC_WINDOWS_PROCESS_MESSAGES_H
#define ZIP7_INC_WINDOWS_PROCESS_MESSAGES_H

namespace NWindows {

void ProcessMessages(HWND window);

}

#endif
