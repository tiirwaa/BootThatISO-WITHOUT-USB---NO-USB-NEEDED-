// DeflateProps.h

#ifndef ZIP7_INC_DEFLATE_PROPS_H
#define ZIP7_INC_DEFLATE_PROPS_H

#endif
